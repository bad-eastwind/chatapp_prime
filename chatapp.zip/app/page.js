// "use client"
// import {socketclient} from './socketclient'
import ChatApp from './ChatApp.js';
function Home(){
  return(
    <div>
      Testing
      <ChatApp/>
    </div>
  )
}

export default Home;